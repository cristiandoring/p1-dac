const AuthService = require('../services/authService');

class AuthController {
  static async login(req, res, next) {
    try {
      const { email, senha } = req.body;
      const resultado = await AuthService.login(email, senha);
      res.status(200).json({
        mensagem: 'Login realizado com sucesso.',
        ...resultado,
      });
    } catch (erro) {
      next(erro);
    }
  }
}

module.exports = AuthController;
