const DashboardService = require('../services/dashboardService');

class DashboardController {
  static async exibir(req, res, next) {
    try {
      const painel = await DashboardService.obterPainel(req.usuario);
      res.status(200).json({
        mensagem: 'Painel carregado com sucesso.',
        ...painel,
      });
    } catch (erro) {
      next(erro);
    }
  }
}

module.exports = DashboardController;
