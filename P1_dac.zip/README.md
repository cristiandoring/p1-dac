# P1 DAC — Sistema de Voluntários e Eventos (IFRS)

Sistema para gerenciamento de eventos e voluntários do IFRS, com controle de inscrições por limite de vagas e autenticação JWT. Desenvolvido com Node.js (Express), React (Vite) e MySQL.

 Instalação e Execução

# 1. Banco de Dados (MySQL)

Conecte ao MySQL via MySQL Workbench (ou seu cliente de preferência) com o usuário root.

Execute o script backend/src/database/p1_dac.sql para criar a base de dados e carregar as informações iniciais.

# 2. Back-end

## Entrar na pasta do backend e instalar dependências
cd backend
npm install

## Criar o arquivo de variáveis de ambiente
cp .env.example .env


Nota: Ajuste a senha do MySQL (DB_PASSWORD) e a chave do JWT (JWT_SECRET) no arquivo .env recém-criado.

## Executar a API em modo de desenvolvimento 
npm run dev


# 3. Front-end

Com o servidor back-end e o MySQL rodando, abra um novo terminal:

## Entrar na pasta do frontend e instalar dependências
cd frontend

npm install

## Executar a aplicação frontend
npm run dev


### Credenciais de Teste

Administrador

login: admin@ifrs.edu.br

senha: 123456

Usuário comum

login:usuario@ifrs.edu.br
senha: 123456

# Documentação da API (Swagger)

http://localhost:3000/api-docs

# Autor

Cristian Doring Molon